/* =====================
   DOM ELEMENTS
===================== */
const profilePic = document.querySelector(".profile-pic");
const nameEl = document.getElementById("name");
const titleEl = document.getElementById("title");
const taglineEl = document.getElementById("tagline");
const introText = document.getElementById("introText");
const skillsEl = document.getElementById("skills");
const projectsEl = document.getElementById("projects");
const educationEl = document.getElementById("education");
const emailEl = document.getElementById("email");
const contactBtn = document.querySelector(".btn");

/* =====================
   PORTFOLIO DATA
===================== */
const portfolio = {
  name: "Darshu",
  title: "Full Stack Developer & UI Designer",
  tagline: "Building powerful digital experiences",
  intro:
    "I am a full stack developer focused on building scalable, responsive, and modern web applications.",
  skills: ["HTML", "CSS", "JavaScript", "Python", "MySQL", "Git"],
  projects: [
    { name: "Business Dashboard", desc: "Analytics dashboard UI" },
    { name: "E-Commerce Platform", desc: "Secure online shopping system" }
  ],
  education: "MCA (Master of Computer Applications) | 2025 – 2027",
  email: "darshuhg07@gmail.com",
  photo: "profile.jpg"
};

/* =====================
   LOAD CONTENT
===================== */
profilePic.src = portfolio.photo;
nameEl.innerText = portfolio.name;
titleEl.innerText = portfolio.title;
taglineEl.innerText = portfolio.tagline;
introText.innerText = portfolio.intro;
educationEl.innerText = portfolio.education;
emailEl.innerText = "Email: " + portfolio.email;

skillsEl.innerHTML = portfolio.skills
  .map(skill => `<div class="card">${skill}</div>`)
  .join("");

projectsEl.innerHTML = portfolio.projects
  .map(
    p => `<div class="card"><h3>${p.name}</h3><p>${p.desc}</p></div>`
  )
  .join("");

/* =====================
   CONTACT BUTTON SCROLL
===================== */
contactBtn.addEventListener("click", () => {
  document.getElementById("contact").scrollIntoView({ behavior: "smooth" });
});

/* =====================
   GALAXY ANIMATION
===================== */
const canvas = document.getElementById("galaxy");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

// Generate stars
const numStars = 300;
let stars = [];

for (let i = 0; i < numStars; i++) {
  stars.push({
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    radius: Math.random() * 1.5 + 0.2,
    speed: Math.random() * 0.5 + 0.05,
    alpha: Math.random() * 0.8 + 0.2
  });
}

// Animate stars
function animateGalaxy() {
  ctx.fillStyle = "#050812"; // dark space background
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  stars.forEach(star => {
    // Move star
    star.y += star.speed;
    if (star.y > canvas.height) star.y = 0;

    // Twinkle
    star.alpha += (Math.random() - 0.5) * 0.05;
    if (star.alpha > 1) star.alpha = 1;
    if (star.alpha < 0.2) star.alpha = 0.2;

    // Draw star
    ctx.beginPath();
    ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(255,255,255,${star.alpha})`;
    ctx.fill();
  });

  requestAnimationFrame(animateGalaxy);
}

animateGalaxy();

// Resize canvas and scale stars
window.addEventListener("resize", () => {
  const wRatio = window.innerWidth / canvas.width;
  const hRatio = window.innerHeight / canvas.height;
  stars.forEach(star => {
    star.x *= wRatio;
    star.y *= hRatio;
  });
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
});
